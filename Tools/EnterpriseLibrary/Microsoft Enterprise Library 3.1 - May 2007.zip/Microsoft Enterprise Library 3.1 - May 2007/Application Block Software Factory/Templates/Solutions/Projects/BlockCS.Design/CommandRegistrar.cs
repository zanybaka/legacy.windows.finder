//===============================================================================
// Microsoft patterns & practices Enterprise Library
// Application Block Software Factory
//===============================================================================
// Copyright � Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.Practices.EnterpriseLibrary.Configuration.Design;
using $Namespace$.Configuration.Design.Properties;

namespace $Namespace$.Configuration.Design
{
    sealed partial class CommandRegistrar : Microsoft.Practices.EnterpriseLibrary.Configuration.Design.CommandRegistrar
    {
        public CommandRegistrar(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
        }

        public override void Register()
        {
            AddBlockCommand();
			AddDefaultCommands(typeof(ApplicationBlockSettingsNode));
        }

		public void AddBlockCommand()
		{
			ConfigurationUICommand cmd = ConfigurationUICommand.CreateSingleUICommand(	ServiceProvider,
                Resources.$NameWithoutDots$,
                Resources.Add$NameWithoutDots$,
                new AddApplicationBlockSettingsNodeCommand(ServiceProvider),
                typeof(ApplicationBlockSettingsNode));
            AddUICommand(cmd, typeof(ConfigurationApplicationNode)); 
		}
	}
}
