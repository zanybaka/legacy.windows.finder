//===============================================================================
// Microsoft patterns & practices Enterprise Library
// Application Block Software Factory
//===============================================================================
// Copyright � Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================

using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing.Design;
using Microsoft.Practices.EnterpriseLibrary.Configuration.Design;

namespace $Namespace$.Configuration.Design
{
	/// <summary>
    /// Represents the <see cref="ApplicationBlockSettings"/> configuration section.
    /// </summary>
	public sealed class ApplicationBlockSettingsNode : ConfigurationNode
	{
        /// <summary>
        /// Initialize a new instance of the <see cref="ApplicationBlockSettingsNode"/> class.
        /// </summary>
        public ApplicationBlockSettingsNode() 
        {
        }		

		/// <summary>
		/// Releases the unmanaged resources used by the <see cref="ApplicationBlockSettingsNode"/> and optionally releases the managed resources.
		/// </summary>
		/// <param name="disposing">
		/// <see langword="true"/> to release both managed and unmanaged resources; <see langword="false"/> to release only unmanaged resources.
		/// </param>
		protected override void Dispose(bool disposing)
		{			
			if (disposing)
			{
			}
			base.Dispose(disposing);
		}

        /// <summary>
        /// Gets the name of the node.
        /// </summary>
		/// <value>
		/// The name of the node.
		/// </value>
        [ReadOnly(true)]
        public override string Name
        {
            get { return base.Name; }            
        }
	}
}
